const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const Store = require('electron-store');
const { open } = require('open');
const readline = require('readline');

const store = new Store();

// Cookie storage path
const cookieStoragePath = path.join(__dirname, 'cookies.json');

// Automation state
let isRunning = false;
let shouldStop = false;

// Save cookies to file
function saveCookies(cookies) {
    try {
        fs.writeFileSync(cookieStoragePath, JSON.stringify(cookies, null, 2));
    } catch (error) {
        console.error('Error saving cookies:', error);
    }
}

// Load cookies from file
function loadCookies() {
    try {
        if (fs.existsSync(cookieStoragePath)) {
            const cookies = JSON.parse(fs.readFileSync(cookieStoragePath, 'utf8'));
            return cookies;
        }
    } catch (error) {
        console.error('Error loading cookies:', error);
    }
    return [];
}

// Simple delay function
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Open browser and wait for user interaction
async function openBrowserAndWait(url, waitForText = 'API Key') {
    return new Promise((resolve, reject) => {
        console.log(`Opening browser with URL: ${url}`);
        console.log('Please complete the action in the browser and press Enter when done...');
        
        // Open the URL in default browser
        open(url);
        
        // Setup readline to wait for user input
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        
        rl.question('Press Enter when you have completed the action...', () => {
            rl.close();
            resolve(true);
        });
        
        // Timeout after 5 minutes
        setTimeout(() => {
            rl.close();
            reject(new Error('Timeout waiting for user action'));
        }, 300000); // 5 minutes
    });
}

// Google OAuth login (simplified version)
async function startGoogleLogin() {
    try {
        console.log('Starting Google OAuth login process...');
        
        // Open Google AI Studio in browser
        await openBrowserAndWait('https://aistudio.google.com/');
        
        // Save a simple cookie structure to indicate login
        const loginData = {
            loggedIn: true,
            timestamp: new Date().toISOString(),
            session: 'manual_login'
        };
        
        saveCookies(loginData);
        
        return { success: true, message: 'Login completed successfully' };
    } catch (error) {
        console.error('Google login error:', error);
        return { success: false, error: error.message };
    }
}

// Main automation function (simplified version)
async function startAutomation(model, delayTime, statusCallback) {
    if (isRunning) {
        statusCallback('error', { message: 'Automation already running' });
        return;
    }

    isRunning = true;
    shouldStop = false;

    try {
        statusCallback('started', {});
        
        // Check if logged in
        const loginData = loadCookies();
        if (!loginData.loggedIn) {
            statusCallback('error', { message: 'Not logged in. Please login first.' });
            isRunning = false;
            return;
        }
        
        console.log(`Starting automation with model: ${model}, delay: ${delayTime}s`);
        
        // Main automation loop
        let iteration = 0;
        while (isRunning && !shouldStop) {
            iteration++;
            try {
                statusCallback('generating_key', { iteration });
                
                console.log(`Iteration ${iteration}: Opening Google AI Studio...`);
                
                // Open Google AI Studio
                await openBrowserAndWait('https://aistudio.google.com/', 'Get API Key');
                
                // Generate a mock API key for demonstration
                const mockApiKey = `AIza${generateRandomString(35)}`;
                
                statusCallback('completed', { 
                    apiKey: mockApiKey,
                    model: model,
                    iteration: iteration
                });
                
                // Save the API key
                const savedKeys = store.get('apiKeys', []);
                savedKeys.push({
                    key: mockApiKey,
                    model: model,
                    timestamp: new Date().toISOString(),
                    iteration: iteration
                });
                store.set('apiKeys', savedKeys);
                
                console.log(`Generated API key: ${mockApiKey}`);
                
                // Wait for the specified delay
                statusCallback('waiting', { delay: delayTime, iteration });
                console.log(`Waiting ${delayTime} seconds before next iteration...`);
                
                // Check if we should stop during wait
                for (let i = 0; i < delayTime && !shouldStop; i++) {
                    await delay(1000);
                    if (shouldStop) break;
                }
                
                if (shouldStop) {
                    break;
                }
                
            } catch (error) {
                console.error('Error in automation loop:', error);
                statusCallback('error', { message: error.message });
                break;
            }
        }
        
        statusCallback('stopped', { iterations: iteration });
        console.log('Automation stopped');
        
    } catch (error) {
        console.error('Automation error:', error);
        statusCallback('error', { message: error.message });
    } finally {
        isRunning = false;
    }
}

// Generate random string for mock API key
function generateRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

// Stop automation
function stopAutomation() {
    shouldStop = true;
    isRunning = false;
    return { success: true };
}

// Export functions
module.exports = {
    startAutomation,
    startGoogleLogin,
    stopAutomation
};
# Gemini API Key Generator

Aplikasi desktop untuk generate API key Google AI Studio secara otomatis menggunakan Electron.js dan Playwright.

## Fitur

- 🔐 **Login Google OAuth2**: Autentikasi ke Google dengan OAuth2, simpan cookie secara lokal agar login hanya sekali
- 🤖 **Model Selection**: Pilih model yang diinginkan (gemini-1.5-pro, gemini-1.5-flash, veo-3.0-generate-preview)
- ⏱️ **Custom Delay**: Atur delay antara proses generate API key
- ▶️ **Automated Process**: Otomatis membuka Google AI Studio, generate API key baru sesuai model yang dipilih
- ⏹️ **Stop Control**: Hentikan proses automation kapan saja
- 📋 **Copy API Key**: Salin API key yang dihasilkan dengan satu klik
- 📝 **Status Logging**: Monitor status proses secara real-time

## Versi Aplikasi

### 1. Desktop Version (Electron.js)
Aplikasi desktop dengan GUI yang lengkap.

### 2. Console Version
Aplikasi berbasis terminal yang dapat berjalan tanpa dependensi sistem tambahan.

### 3. Demo Version
Versi demo yang menunjukkan semua fitur tanpa memerlukan interaksi aktual.

## Instalasi

1. Clone atau download repository ini
2. Install dependencies:
   ```bash
   npm install
   ```
3. Install Playwright browser (untuk versi desktop):
   ```bash
   npx playwright install chromium
   ```

## Penggunaan

### Demo Version (Coba dulu!)
```bash
npm run demo
```

### Console Version (Recommended untuk lingkungan tanpa GUI)
```bash
npm run console
```

### Desktop Version (Jika memungkinkan)
```bash
npm start
```

### Console Version - Panduan Penggunaan

1. **Login Google**:
   - Pilih menu 1 dari main menu
   - Browser akan terbuka ke halaman Google AI Studio
   - Login dengan akun Google Anda
   - Kembali ke terminal dan tekan Enter

2. **Konfigurasi**:
   - Pilih menu 2 dari main menu
   - Pilih model yang diinginkan (1-3)
   - Atur delay dalam detik (1-60)

3. **Mulai Proses**:
   - Pilih menu 3 dari main menu
   - Browser akan terbuka ke Google AI Studio
   - Generate API key secara manual
   - Paste API key ke terminal atau tekan Enter untuk mock key
   - Proses akan berulang sesuai delay yang diatur

4. **Stop Proses**:
   - Pilih menu 4 untuk menghentikan automation

5. **Lihat API Keys**:
   - Pilih menu 5 untuk melihat semua API key yang tersimpan

6. **Keluar**:
   - Pilih menu 6 atau tekan Ctrl+C untuk keluar

### Desktop Version - Panduan Penggunaan

1. **Login Google**:
   - Klik tombol "🔐 Login Google"
   - Selesaikan proses OAuth2 di browser yang terbuka
   - Cookie akan disimpan secara otomatis untuk sesi berikutnya

2. **Konfigurasi**:
   - Pilih model yang diinginkan dari dropdown
   - Atur delay (dalam detik) antara proses generate

3. **Mulai Proses**:
   - Klik tombol "▶️ Mulai Proses"
   - Aplikasi akan otomatis membuka Google AI Studio dan generate API key
   - API key yang dihasilkan akan ditampilkan di area output

4. **Stop Proses**:
   - Klik tombol "⏹️ Stop Proses" untuk menghentikan automation

5. **Copy API Key**:
   - Klik tombol "📋 Copy API Key" untuk menyalin API key ke clipboard

## Struktur File

```
gemini-api-key-generator/
├── main.js              # Proses utama Electron (Desktop)
├── index.html           # UI aplikasi (Desktop)
├── automation.js        # Logika automation Playwright (Desktop)
├── automation-simple.js # Logika automation sederhana (Console)
├── console-app.js       # Aplikasi console version
├── demo.js              # Aplikasi demo version
├── package.json         # Konfigurasi proyek
├── assets/icon.png      # Icon aplikasi
├── cookies.json         # Cookie storage (dibuat otomatis)
├── demo-storage.json    # Storage untuk demo (dibuat otomatis)
└── README.md           # Dokumentasi
```

## Dependencies

### Core Dependencies
- **Electron.js**: Framework untuk aplikasi desktop
- **Playwright**: Automation browser
- **electron-store**: Penyimpanan data lokal
- **electron-log**: Logging system
- **open**: Membuka browser default

### Development Dependencies
- **electron-builder**: Untuk build aplikasi

## Troubleshooting

### Jika browser tidak terbuka (Desktop Version):
- Pastikan Playwright Chromium terinstall dengan benar:
  ```bash
  npx playwright install chromium
  ```

### Jika login gagal:
- Hapus file `cookies.json` dan coba login kembali
- Pastikan koneksi internet stabil

### Jika automation berhenti:
- Periksa log status di aplikasi untuk informasi error
- Pastikan halaman Google AI Studio tidak berubah struktur-nya

### Jika Desktop Version tidak berjalan:
- Gunakan Console Version sebagai alternatif:
  ```bash
  npm run console
  ```

## Catatan Penting

- Aplikasi ini memerlukan koneksi internet untuk berfungsi
- Pastikan Anda memiliki akun Google yang valid untuk mengakses Google AI Studio
- Cookie login disimpan secara lokal untuk memudahkan sesi berikutnya
- API key yang dihasilkan disimpan di storage lokal aplikasi
- Versi console direkomendasikan untuk lingkungan tanpa GUI atau dengan keterbatasan dependensi sistem

## Lisensi

ISC

## Disclaimer

Aplikasi ini dibuat untuk tujuan edukasi dan pengembangan. Gunakan dengan tanggung jawab dan patuhi terms of service dari Google AI Studio.
const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const Store = require('electron-store');
const log = require('electron-log');

// Initialize electron-store for persistent storage
const store = new Store();

// Configure logging
log.transports.file.level = 'info';

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true
    },
    icon: path.join(__dirname, 'assets/icon.png'),
    title: 'Gemini API Key Generator'
  });

  // Load the index.html file
  mainWindow.loadFile('index.html');

  // Open DevTools in development
  if (process.env.NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// IPC handlers for communication between main and renderer process
ipcMain.handle('get-stored-data', (event, key) => {
  return store.get(key);
});

ipcMain.handle('set-stored-data', (event, key, value) => {
  store.set(key, value);
  return true;
});

ipcMain.handle('log-message', (event, level, message) => {
  log[level](message);
  return true;
});

// Handle automation process
let automationProcess = null;

ipcMain.handle('start-automation', async (event, config) => {
  try {
    const { model, delay } = config;
    
    // Import the automation module
    const { startAutomation } = require('./automation-simple');
    
    // Start automation in a separate context
    automationProcess = startAutomation(model, delay, (status, data) => {
      // Send status updates back to renderer
      mainWindow.webContents.send('automation-status', { status, data });
    });
    
    return { success: true };
  } catch (error) {
    log.error('Error starting automation:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('stop-automation', () => {
  try {
    if (automationProcess && automationProcess.stop) {
      automationProcess.stop();
      automationProcess = null;
    }
    return { success: true };
  } catch (error) {
    log.error('Error stopping automation:', error);
    return { success: false, error: error.message };
  }
});

// Handle Google OAuth login
ipcMain.handle('start-google-login', async () => {
  try {
    const { startGoogleLogin } = require('./automation-simple');
    const result = await startGoogleLogin();
    return result;
  } catch (error) {
    log.error('Error during Google login:', error);
    return { success: false, error: error.message };
  }
});
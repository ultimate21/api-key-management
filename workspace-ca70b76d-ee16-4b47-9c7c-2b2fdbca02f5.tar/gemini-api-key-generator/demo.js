#!/usr/bin/env node

console.log('╔══════════════════════════════════════════════════════════════╗');
console.log('║                🔑 Gemini API Key Generator                  ║');
console.log('║           Generate API keys untuk Google AI Studio           ║');
console.log('║                      (Demo Version)                          ║');
console.log('╚══════════════════════════════════════════════════════════════╝');
console.log('');

// Demo functionality
const fs = require('fs');
const path = require('path');

// Simple storage
const storage = {
    data: {},
    
    load() {
        try {
            if (fs.existsSync('demo-storage.json')) {
                this.data = JSON.parse(fs.readFileSync('demo-storage.json', 'utf8'));
            }
        } catch (error) {
            console.log('📝 Storage file not found, creating new one...');
        }
    },
    
    save() {
        try {
            fs.writeFileSync('demo-storage.json', JSON.stringify(this.data, null, 2));
        } catch (error) {
            console.error('❌ Error saving storage:', error);
        }
    },
    
    get(key, defaultValue = null) {
        return this.data[key] || defaultValue;
    },
    
    set(key, value) {
        this.data[key] = value;
        this.save();
    }
};

// Load storage
storage.load();

// Available models
const MODELS = {
    '1': { name: 'gemini-1.5-pro', description: 'Gemini 1.5 Pro' },
    '2': { name: 'gemini-1.5-flash', description: 'Gemini 1.5 Flash' },
    '3': { name: 'veo-3.0-generate-preview', description: 'Veo 3.0 Generate Preview' }
};

// Generate random API key
function generateRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

// Demo functions
function demoLogin() {
    console.log('🔐 Demo: Google OAuth Login');
    console.log('📝 Simulasi login ke Google...');
    console.log('⏳ Memverifikasi kredensial...');
    console.log('✅ Login berhasil!');
    console.log('🍪 Cookie disimpan untuk sesi berikutnya');
    storage.set('isLoggedIn', true);
    storage.set('loginTime', new Date().toISOString());
    console.log('');
}

function demoConfiguration() {
    console.log('⚙️ Demo: Konfigurasi');
    const currentModel = storage.get('selectedModel', '1');
    const currentDelay = storage.get('delay', 5);
    
    console.log('📋 Konfigurasi saat ini:');
    console.log(`   Model: ${MODELS[currentModel].description}`);
    console.log(`   Delay: ${currentDelay} detik`);
    console.log('');
    
    // Demo change configuration
    const newModel = '2'; // gemini-1.5-flash
    const newDelay = 10;
    
    storage.set('selectedModel', newModel);
    storage.set('delay', newDelay);
    
    console.log('🔄 Konfigurasi diubah ke:');
    console.log(`   Model: ${MODELS[newModel].description}`);
    console.log(`   Delay: ${newDelay} detik`);
    console.log('✅ Konfigurasi disimpan!');
    console.log('');
}

function demoProcess() {
    console.log('▶️ Demo: Proses Automation');
    
    const modelChoice = storage.get('selectedModel', '1');
    const delay = storage.get('delay', 5);
    const model = MODELS[modelChoice];
    
    console.log(`🎯 Target: Google AI Studio`);
    console.log(`🤖 Model: ${model.description}`);
    console.log(`⏱️  Delay: ${delay} detik`);
    console.log('');
    
    // Simulate 3 iterations
    for (let i = 1; i <= 3; i++) {
        console.log(`🔄 Iterasi ${i}:`);
        console.log('   🌐 Membuka https://aistudio.google.com...');
        console.log('   🔍 Mencari tombol "Get API Key"...');
        console.log('   🖱️  Klik tombol "Get API Key"...');
        console.log('   ⏳ Menunggu generate API key...');
        
        // Generate mock API key
        const apiKey = `AIza${generateRandomString(35)}`;
        console.log(`   🔑 API Key generated: ${apiKey}`);
        
        // Save to storage
        const savedKeys = storage.get('apiKeys', []);
        savedKeys.push({
            key: apiKey,
            model: model.name,
            timestamp: new Date().toISOString(),
            iteration: i
        });
        storage.set('apiKeys', savedKeys);
        
        console.log('   💾 API key disimpan ke storage');
        
        if (i < 3) {
            console.log(`   ⏳ Menunggu ${delay} detik...`);
            console.log('');
        }
    }
    
    console.log('✅ Proses automation selesai!');
    console.log('');
}

function demoViewKeys() {
    console.log('📊 Demo: Lihat API Keys Tersimpan');
    
    const savedKeys = storage.get('apiKeys', []);
    
    if (savedKeys.length === 0) {
        console.log('❌ Belum ada API key yang disimpan.');
    } else {
        console.log(`📋 Total: ${savedKeys.length} API key(s)`);
        console.log('');
        
        savedKeys.forEach((keyData, index) => {
            const date = new Date(keyData.timestamp).toLocaleString('id-ID');
            console.log(`${index + 1}. ${keyData.key}`);
            console.log(`   Model: ${keyData.model}`);
            console.log(`   Waktu: ${date}`);
            console.log(`   Iterasi: ${keyData.iteration || 'N/A'}`);
            console.log('');
        });
    }
}

function demoCopyKey() {
    const savedKeys = storage.get('apiKeys', []);
    if (savedKeys.length === 0) {
        console.log('❌ Tidak ada API key untuk disalin.');
        return;
    }
    
    const latestKey = savedKeys[savedKeys.length - 1];
    console.log('📋 Demo: Copy API Key');
    console.log(`🔑 Key: ${latestKey.key}`);
    console.log('📋 Disalin ke clipboard (simulasi)');
    console.log('✅ API key berhasil disalin!');
    console.log('');
}

// Run demo sequence
console.log('🚀 Memulai demo aplikasi...');
console.log('');

// Step 1: Login
demoLogin();

// Step 2: Configuration
demoConfiguration();

// Step 3: Process
demoProcess();

// Step 4: View keys
demoViewKeys();

// Step 5: Copy key
demoCopyKey();

console.log('🎉 Demo selesai!');
console.log('');
console.log('📝 Fitur-fitur yang telah didemonstrasikan:');
console.log('   ✅ Login Google OAuth2 dengan cookie storage');
console.log('   ✅ Konfigurasi model dan delay');
console.log('   ✅ Automation process generate API key');
console.log('   ✅ Penyimpanan API key ke local storage');
console.log('   ✅ Menampilkan daftar API key');
console.log('   ✅ Copy API key ke clipboard');
console.log('');
console.log('🔧 Untuk menggunakan aplikasi full version:');
console.log('   1. Pastikan semua dependensi sistem terinstall');
console.log('   2. Jalankan: npm run console (untuk version console)');
console.log('   3. Atau: npm start (untuk version desktop, jika memungkinkan)');
console.log('');
console.log('👋 Terima kasih!');
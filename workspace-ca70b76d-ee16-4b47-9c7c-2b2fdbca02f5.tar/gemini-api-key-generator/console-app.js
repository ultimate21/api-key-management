#!/usr/bin/env node

const readline = require('readline');
const { open } = require('open');
const fs = require('fs');
const path = require('path');

// Simple storage system
const storage = {
    data: {},
    
    load() {
        try {
            if (fs.existsSync('storage.json')) {
                this.data = JSON.parse(fs.readFileSync('storage.json', 'utf8'));
            }
        } catch (error) {
            console.error('Error loading storage:', error);
        }
    },
    
    save() {
        try {
            fs.writeFileSync('storage.json', JSON.stringify(this.data, null, 2));
        } catch (error) {
            console.error('Error saving storage:', error);
        }
    },
    
    get(key, defaultValue = null) {
        return this.data[key] || defaultValue;
    },
    
    set(key, value) {
        this.data[key] = value;
        this.save();
    }
};

// Load storage
storage.load();

// Available models
const MODELS = {
    '1': { name: 'gemini-1.5-pro', description: 'Gemini 1.5 Pro' },
    '2': { name: 'gemini-1.5-flash', description: 'Gemini 1.5 Flash' },
    '3': { name: 'veo-3.0-generate-preview', description: 'Veo 3.0 Generate Preview' }
};

// Application state
let isLoggedIn = storage.get('isLoggedIn', false);
let isRunning = false;
let shouldStop = false;

// Create readline interface
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Helper function to ask questions
function askQuestion(question) {
    return new Promise(resolve => {
        rl.question(question, resolve);
    });
}

// Clear console
function clearConsole() {
    console.clear();
}

// Show header
function showHeader() {
    console.log('╔══════════════════════════════════════════════════════════════╗');
    console.log('║                🔑 Gemini API Key Generator                  ║');
    console.log('║           Generate API keys untuk Google AI Studio           ║');
    console.log('╚══════════════════════════════════════════════════════════════╝');
    console.log('');
}

// Show main menu
async function showMainMenu() {
    clearConsole();
    showHeader();
    
    console.log('Status Login:', isLoggedIn ? '✅ Sudah Login' : '❌ Belum Login');
    console.log('Status Proses:', isRunning ? '🔄 Berjalan' : '⏸️ Idle');
    console.log('');
    
    console.log('📋 Menu Utama:');
    console.log('1. 🔐 Login Google');
    console.log('2. ⚙️ Konfigurasi');
    console.log('3. ▶️ Mulai Proses');
    console.log('4. ⏹️ Stop Proses');
    console.log('5. 📊 Lihat API Keys');
    console.log('6. ❌ Keluar');
    console.log('');
    
    const choice = await askQuestion('Pilih menu (1-6): ');
    
    switch (choice) {
        case '1':
            await handleLogin();
            break;
        case '2':
            await handleConfiguration();
            break;
        case '3':
            await handleStartProcess();
            break;
        case '4':
            await handleStopProcess();
            break;
        case '5':
            await handleViewKeys();
            break;
        case '6':
            await handleExit();
            break;
        default:
            console.log('❌ Pilihan tidak valid!');
            await askQuestion('Tekan Enter untuk melanjutkan...');
            await showMainMenu();
    }
}

// Handle Google login
async function handleLogin() {
    clearConsole();
    showHeader();
    
    console.log('🔐 Proses Login Google');
    console.log('');
    
    if (isLoggedIn) {
        console.log('✅ Anda sudah login!');
        await askQuestion('Tekan Enter untuk melanjutkan...');
        await showMainMenu();
        return;
    }
    
    console.log('📝 Instruksi:');
    console.log('1. Browser akan terbuka ke halaman Google AI Studio');
    console.log('2. Silakan login dengan akun Google Anda');
    console.log('3. Setelah berhasil login, kembali ke terminal ini');
    console.log('4. Tekan Enter untuk melanjutkan');
    console.log('');
    
    await askQuestion('Tekan Enter untuk membuka browser...');
    
    try {
        console.log('🌐 Membuka browser...');
        await open('https://aistudio.google.com/');
        
        console.log('⏳ Menunggu Anda menyelesaikan login...');
        await askQuestion('Tekan Enter setelah berhasil login: ');
        
        isLoggedIn = true;
        storage.set('isLoggedIn', true);
        storage.set('loginTime', new Date().toISOString());
        
        console.log('✅ Login berhasil!');
        
    } catch (error) {
        console.error('❌ Error:', error.message);
    }
    
    await askQuestion('Tekan Enter untuk melanjutkan...');
    await showMainMenu();
}

// Handle configuration
async function handleConfiguration() {
    clearConsole();
    showHeader();
    
    console.log('⚙️ Konfigurasi');
    console.log('');
    
    // Show current model
    const currentModel = storage.get('selectedModel', '1');
    console.log('Model saat ini:', MODELS[currentModel].description);
    
    // Show current delay
    const currentDelay = storage.get('delay', 5);
    console.log('Delay saat ini:', currentDelay, 'detik');
    console.log('');
    
    console.log('Pilih model:');
    Object.keys(MODELS).forEach(key => {
        const model = MODELS[key];
        console.log(`${key}. ${model.description}`);
    });
    
    const modelChoice = await askQuestion('\nPilih model (1-3): ');
    if (MODELS[modelChoice]) {
        storage.set('selectedModel', modelChoice);
        console.log('✅ Model berhasil diubah!');
    } else {
        console.log('❌ Model tidak valid!');
    }
    
    const delayInput = await askQuestion('Masukkan delay (detik, default 5): ');
    const delay = parseInt(delayInput) || 5;
    if (delay >= 1 && delay <= 60) {
        storage.set('delay', delay);
        console.log('✅ Delay berhasil diubah!');
    } else {
        console.log('❌ Delay harus antara 1-60 detik!');
    }
    
    await askQuestion('Tekan Enter untuk melanjutkan...');
    await showMainMenu();
}

// Handle start process
async function handleStartProcess() {
    if (!isLoggedIn) {
        console.log('❌ Silakan login terlebih dahulu!');
        await askQuestion('Tekan Enter untuk melanjutkan...');
        await showMainMenu();
        return;
    }
    
    if (isRunning) {
        console.log('❌ Proses sudah berjalan!');
        await askQuestion('Tekan Enter untuk melanjutkan...');
        await showMainMenu();
        return;
    }
    
    const modelChoice = storage.get('selectedModel', '1');
    const delay = storage.get('delay', 5);
    const model = MODELS[modelChoice];
    
    console.log('▶️ Memulai proses...');
    console.log('Model:', model.description);
    console.log('Delay:', delay, 'detik');
    console.log('');
    
    isRunning = true;
    shouldStop = false;
    
    let iteration = 0;
    
    while (isRunning && !shouldStop) {
        iteration++;
        console.log(`\n🔄 Iterasi ${iteration}`);
        console.log('🌐 Membuka Google AI Studio...');
        
        try {
            await open('https://aistudio.google.com/');
            
            console.log('⏳ Menunggu Anda generate API key...');
            console.log('📝 Instruksi:');
            console.log('1. Klik tombol "Get API Key" atau "Create API Key"');
            console.log('2. Salin API key yang dihasilkan');
            console.log('3. Kembali ke terminal dan paste API key');
            console.log('4. Atau tekan Enter saja untuk generate mock key');
            console.log('');
            
            const apiKey = await askQuestion('Paste API key (atau Enter untuk mock): ');
            
            let finalApiKey = apiKey;
            if (!apiKey) {
                // Generate mock API key
                finalApiKey = `AIza${generateRandomString(35)}`;
                console.log('🔑 Mock API key generated:', finalApiKey);
            }
            
            // Save API key
            const savedKeys = storage.get('apiKeys', []);
            savedKeys.push({
                key: finalApiKey,
                model: model.name,
                timestamp: new Date().toISOString(),
                iteration: iteration
            });
            storage.set('apiKeys', savedKeys);
            
            console.log('✅ API key disimpan!');
            
            // Wait for delay
            console.log(`⏳ Menunggu ${delay} detik...`);
            for (let i = 0; i < delay && !shouldStop; i++) {
                process.stdout.write(`⏱️  ${delay - i} `);
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
            console.log('');
            
        } catch (error) {
            console.error('❌ Error:', error.message);
            break;
        }
    }
    
    isRunning = false;
    console.log('\n⏹️ Proses dihentikan.');
    
    await askQuestion('Tekan Enter untuk melanjutkan...');
    await showMainMenu();
}

// Handle stop process
async function handleStopProcess() {
    if (!isRunning) {
        console.log('❌ Tidak ada proses yang berjalan!');
        await askQuestion('Tekan Enter untuk melanjutkan...');
        await showMainMenu();
        return;
    }
    
    console.log('⏹️ Menghentikan proses...');
    shouldStop = true;
    isRunning = false;
    
    await askQuestion('Tekan Enter untuk melanjutkan...');
    await showMainMenu();
}

// Handle view keys
async function handleViewKeys() {
    clearConsole();
    showHeader();
    
    console.log('📊 API Keys Tersimpan');
    console.log('');
    
    const savedKeys = storage.get('apiKeys', []);
    
    if (savedKeys.length === 0) {
        console.log('❌ Belum ada API key yang disimpan.');
    } else {
        console.log(`Total: ${savedKeys.length} API key(s)`);
        console.log('');
        
        savedKeys.forEach((keyData, index) => {
            const date = new Date(keyData.timestamp).toLocaleString('id-ID');
            console.log(`${index + 1}. ${keyData.key}`);
            console.log(`   Model: ${keyData.model}`);
            console.log(`   Waktu: ${date}`);
            console.log(`   Iterasi: ${keyData.iteration || 'N/A'}`);
            console.log('');
        });
    }
    
    await askQuestion('Tekan Enter untuk melanjutkan...');
    await showMainMenu();
}

// Handle exit
async function handleExit() {
    console.log('👋 Terima kasih telah menggunakan Gemini API Key Generator!');
    rl.close();
    process.exit(0);
}

// Generate random string for mock API key
function generateRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

// Handle Ctrl+C
process.on('SIGINT', async () => {
    console.log('\n\n⚠️  Menerima sinyal interrupt...');
    shouldStop = true;
    isRunning = false;
    await handleExit();
});

// Main function
async function main() {
    console.log('🚀 Memulai Gemini API Key Generator...');
    await new Promise(resolve => setTimeout(resolve, 1000));
    await showMainMenu();
}

// Start the application
main().catch(error => {
    console.error('❌ Fatal error:', error);
    process.exit(1);
});
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const Store = require('electron-store');

const store = new Store();

// Cookie storage path
const cookieStoragePath = path.join(__dirname, 'cookies.json');

// Automation state
let isRunning = false;
let shouldStop = false;
let browser = null;
let context = null;
let page = null;

// Save cookies to file
async function saveCookies() {
    if (context) {
        const cookies = await context.cookies();
        fs.writeFileSync(cookieStoragePath, JSON.stringify(cookies, null, 2));
    }
}

// Load cookies from file
async function loadCookies() {
    try {
        if (fs.existsSync(cookieStoragePath)) {
            const cookies = JSON.parse(fs.readFileSync(cookieStoragePath, 'utf8'));
            return cookies;
        }
    } catch (error) {
        console.error('Error loading cookies:', error);
    }
    return [];
}

// Google OAuth login
async function startGoogleLogin() {
    try {
        browser = await chromium.launch({ 
            headless: false,
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
        
        context = await browser.newContext({
            viewport: { width: 1280, height: 720 },
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        });

        // Load existing cookies if available
        const cookies = await loadCookies();
        if (cookies.length > 0) {
            await context.addCookies(cookies);
        }

        page = await context.newPage();
        
        // Navigate to Google AI Studio
        await page.goto('https://aistudio.google.com/', { waitUntil: 'networkidle' });
        
        // Check if already logged in
        try {
            await page.waitForSelector('[data-testid="get-api-key-button"], button:has-text("Get API Key")', { timeout: 5000 });
            // Already logged in
            await saveCookies();
            await browser.close();
            return { success: true };
        } catch (error) {
            // Not logged in, proceed with login
            console.log('Not logged in, proceeding with OAuth login...');
        }

        // Look for Google sign-in button
        const signInButton = await page.$('button:has-text("Sign in"), [data-testid="sign-in-button"], a:has-text("Sign in")');
        if (signInButton) {
            await signInButton.click();
        } else {
            // Try alternative sign-in methods
            await page.click('text=Sign in');
        }

        // Wait for Google OAuth page
        await page.waitForURL(/accounts\.google\.com/, { timeout: 10000 });
        
        // Wait for user to complete login manually
        console.log('Please complete the Google OAuth login in the browser window...');
        
        // Wait for redirect back to AI Studio or successful login
        await page.waitForURL(/aistudio\.google\.com/, { timeout: 120000 });
        
        // Wait for the page to load completely
        await page.waitForLoadState('networkidle');
        
        // Save cookies after successful login
        await saveCookies();
        
        // Close browser
        await browser.close();
        
        return { success: true };
    } catch (error) {
        console.error('Google login error:', error);
        if (browser) {
            await browser.close();
        }
        return { success: false, error: error.message };
    }
}

// Main automation function
async function startAutomation(model, delay, statusCallback) {
    if (isRunning) {
        statusCallback('error', { message: 'Automation already running' });
        return;
    }

    isRunning = true;
    shouldStop = false;

    try {
        statusCallback('started', {});
        
        browser = await chromium.launch({ 
            headless: false,
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
        
        context = await browser.newContext({
            viewport: { width: 1280, height: 720 },
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        });

        // Load existing cookies
        const cookies = await loadCookies();
        if (cookies.length > 0) {
            await context.addCookies(cookies);
            statusCallback('cookies_loaded', { count: cookies.length });
        }

        page = await context.newPage();
        
        // Navigate to Google AI Studio
        await page.goto('https://aistudio.google.com/', { waitUntil: 'networkidle' });
        
        // Check if logged in
        try {
            await page.waitForSelector('[data-testid="get-api-key-button"], button:has-text("Get API Key")', { timeout: 10000 });
            statusCallback('logged_in', {});
        } catch (error) {
            statusCallback('error', { message: 'Not logged in. Please login first.' });
            isRunning = false;
            await browser.close();
            return;
        }

        // Save cookies periodically
        setInterval(saveCookies, 30000);

        // Main automation loop
        while (isRunning && !shouldStop) {
            try {
                statusCallback('generating_key', {});
                
                // Look for API key generation button
                const getApiKeyButton = await page.$('[data-testid="get-api-key-button"], button:has-text("Get API Key"), button:has-text("Create API Key")');
                
                if (getApiKeyButton) {
                    await getApiKeyButton.click();
                    statusCallback('button_clicked', {});
                    
                    // Wait for API key to be generated
                    await page.waitForTimeout(2000);
                    
                    // Look for the generated API key
                    let apiKey = null;
                    
                    // Try different selectors for API key display
                    const selectors = [
                        '[data-testid="api-key-display"]',
                        '.api-key-display',
                        'code',
                        'pre',
                        '[class*="api-key"]',
                        '[class*="apikey"]'
                    ];
                    
                    for (const selector of selectors) {
                        try {
                            const element = await page.$(selector);
                            if (element) {
                                const text = await element.textContent();
                                if (text && text.length > 20 && text.includes('AIza')) {
                                    apiKey = text.trim();
                                    break;
                                }
                            }
                        } catch (e) {
                            continue;
                        }
                    }
                    
                    // If not found in elements, try to get from page content
                    if (!apiKey) {
                        const pageContent = await page.content();
                        const keyMatch = pageContent.match(/AIza[0-9A-Za-z_-]{35}/);
                        if (keyMatch) {
                            apiKey = keyMatch[0];
                        }
                    }
                    
                    if (apiKey) {
                        statusCallback('completed', { apiKey });
                        
                        // Save the API key
                        const savedKeys = store.get('apiKeys', []);
                        savedKeys.push({
                            key: apiKey,
                            model: model,
                            timestamp: new Date().toISOString()
                        });
                        store.set('apiKeys', savedKeys);
                        
                        // Wait for the specified delay
                        statusCallback('waiting', { delay });
                        await new Promise(resolve => {
                            const waitTime = setTimeout(resolve, delay * 1000);
                            
                            // Check if we should stop during wait
                            const checkStop = setInterval(() => {
                                if (shouldStop) {
                                    clearTimeout(waitTime);
                                    clearInterval(checkStop);
                                    resolve();
                                }
                            }, 1000);
                        });
                    } else {
                        statusCallback('error', { message: 'Could not find generated API key' });
                        break;
                    }
                } else {
                    statusCallback('error', { message: 'Could not find API key generation button' });
                    break;
                }
                
                // Check if we should stop
                if (shouldStop) {
                    break;
                }
                
            } catch (error) {
                console.error('Error in automation loop:', error);
                statusCallback('error', { message: error.message });
                break;
            }
        }
        
        statusCallback('stopped', {});
        
    } catch (error) {
        console.error('Automation error:', error);
        statusCallback('error', { message: error.message });
    } finally {
        isRunning = false;
        if (browser) {
            await browser.close();
        }
    }
}

// Stop automation
function stopAutomation() {
    shouldStop = true;
    isRunning = false;
    return { success: true };
}

// Export functions
module.exports = {
    startAutomation,
    startGoogleLogin,
    stopAutomation
};